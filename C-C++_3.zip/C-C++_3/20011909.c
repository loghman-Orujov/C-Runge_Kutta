#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define MAX_ITER 1000 // Maksimum iterasyon say�s�

// Struct yap�s� tan�mlama
struct DiferansiyelDenklem {
    int elemanSayisi;
    double katsayilar[10]; // Max 10 eleman destekleniyor
    int dereceler[10]; // Max 10 eleman destekleniyor
};

// Diferansiyel denklemin sa� taraf�n� hesaplayan fonksiyon
double f(double x, double y, struct DiferansiyelDenklem denklem) {
    double sum = 0.0;
    int i;
    for ( i = 0; i < denklem.elemanSayisi; ++i) {
        sum += denklem.katsayilar[i] * pow(x, denklem.dereceler[i]);
    }
    return sum;
}

// Runge-Kutta-4 y�ntemiyle diferansiyel denklemi ��zen fonksiyon
void rungeKutta(struct DiferansiyelDenklem denklem, double x0, double y0, double h, int iter, double gercekSonuc) {
    double x = x0;
    double y = y0;
    double k1, k2, k3, k4;
    double hata;
    int i;

    printf("Runge-Kutta-4 Yontemi ile Denklem Cozumu:\n");
    printf("x\t y\t Sonuc\t Hata\n");
    printf("%.4f\t%.4f\t%.4f\t0.0000\n", x, y, gercekSonuc);

    for ( i = 0; i < iter; ++i) {
        k1 = h * f(x, y, denklem);
        k2 = h * f(x + h / 2, y + k1 / 2, denklem);
        k3 = h * f(x + h / 2, y + k2 / 2, denklem);
        k4 = h * f(x + h, y + k3, denklem);

        y = y + (k1 + 2 * k2 + 2 * k3 + k4) / 6;
        x = x + h;

        hata = fabs(y - gercekSonuc);

        printf("%.4f\t%.4f\t%.4f\t%.4f\n", x, y, gercekSonuc, hata);
    }
}

void denklemiYazdir(struct DiferansiyelDenklem denklem) {
    int i;
    printf("Olusturulan diferansiyel denklem: y' = ");
    for (i = 0; i < denklem.elemanSayisi; ++i) {
        if (i != 0) {
            printf(" + ");
        }
        printf("%.2lfy^%d", denklem.katsayilar[i], denklem.dereceler[i]);
    }
    printf("\n");
}


int main() {
    struct DiferansiyelDenklem denklem;
    double x0, y0, h, gercekSonuc;
    int iter;
    int i;

    printf("Diferansiyel denklemin eleman sayisini girin: ");
    scanf("%d", &denklem.elemanSayisi);

    if (denklem.elemanSayisi > 10 || denklem.elemanSayisi <= 0) {
        printf("Hatali eleman sayisi. Program sonlandirildi.\n");
        return 1;
    }

    printf("Her bir elemanin katsayisini ve derecesini girin:\n");
    for ( i = 0; i < denklem.elemanSayisi; ++i) {
        printf("Katsayi %d: ", i + 1);
        scanf("%lf", &denklem.katsayilar[i]);
        printf("Derece %d: ", i + 1);
        scanf("%d", &denklem.dereceler[i]);
    }
    printf("\n");
    denklemiYazdir(denklem);

    printf("Baslangic degerlerini girin:\n");
    printf("x0: ");
    scanf("%lf", &x0);
    printf("y0: ");
    scanf("%lf", &y0);

    printf("Adim boyutunu girin (h): ");
    scanf("%lf", &h);

    printf("Iterasyon sayisini girin: ");
    scanf("%d", &iter);

    printf("Gercek sonucu girin: ");
    scanf("%lf", &gercekSonuc);

    // Diferansiyel denklemi ��zme
    rungeKutta(denklem, x0, y0, h, iter, gercekSonuc);

    return 0;
}

